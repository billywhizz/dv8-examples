wget https://github.com/billywhizz/dv8-releases/archive/v0.0.7.tar.gz
tar -zxvf v0.0.7.tar.gz
sudo cp dv8-releases-0.0.7/linux-x86_64/dv8 /usr/local/bin
rm -fr dv8-releases-0.0.7
rm -f v0.0.7.tar.gz